package com.aleeh.tauar.ui.productSubCategories

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.aleeh.tauar.R
import com.aleeh.tauar.ui.components.HeaderView
import com.aleeh.tauar.ui.productCategories.model.UICategory
import com.aleeh.tauar.ui.productCategories.model.UISubCategory
import com.aleeh.tauar.ui.shopsMap.ShopsMapScreen


class ProductSubCategoriesScreen(
    private val category: UICategory
) : Screen {

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        ProductSubCategoriesContent(category = this.category, onBackPressed = {
            navigator.pop()
        }, onItemClick = {
            navigator.push(ShopsMapScreen())
        })
    }


    @Composable
    private fun ProductSubCategoriesContent(
        category: UICategory,
        onItemClick: (UISubCategory) -> Unit,
        onBackPressed: () -> Unit
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {
            HeaderView(title = category.name) {
                onBackPressed()
            }
            LazyColumn(modifier = Modifier.padding(top = 8.dp), content = {
                items(category.listOfSubcategories.size) {
                    ProductSubCategoryItem(subCategory = category.listOfSubcategories[it]) {
                        onItemClick(it)
                    }
                }
            })
        }
    }


    @Composable
    private fun ProductSubCategoryItem(
        subCategory: UISubCategory,
        onItemClick: (UISubCategory) -> Unit
    ) {
        Column(modifier = Modifier
            .background(color = colorResource(id = R.color.white))
            .clickable {
                onItemClick(subCategory)
            }) {
            Row {
                Text(
                    modifier = Modifier
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .weight(1f),
                    text = subCategory.name,
                    fontFamily = FontFamily(Font(R.font.montserrat_regular))
                )
                Image(
                    modifier = Modifier.align(Alignment.CenterVertically),
                    painter = painterResource(id = R.drawable.chevron_left),
                    contentDescription = null
                )
            }
            Divider(modifier = Modifier.fillMaxWidth(), thickness = 1.dp, color = Color.Gray)
        }
    }
}