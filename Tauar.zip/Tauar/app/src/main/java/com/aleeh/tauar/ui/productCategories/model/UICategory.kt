package com.aleeh.tauar.ui.productCategories.model

data class UICategory(
    val id: Int,
    val name: String,
    val listOfSubcategories: List<UISubCategory>,
    val icon: Int,
    val color: Int
)