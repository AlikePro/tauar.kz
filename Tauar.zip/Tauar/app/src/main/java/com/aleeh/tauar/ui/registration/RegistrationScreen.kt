package com.aleeh.tauar.ui.registration

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.aleeh.tauar.R
import com.aleeh.tauar.ui.authorization.AuthorizationScreen
import com.aleeh.tauar.ui.components.Field
import com.aleeh.tauar.ui.productCategories.ProductCategoriesScreen


class RegistrationScreen : Screen {

    @Composable
    override fun Content() {
        RegistrationContent()
    }

    @Composable
    private fun RegistrationContent() {
        val navigator = LocalNavigator.currentOrThrow
        Box(
            modifier = Modifier
                .background(color = colorResource(id = R.color.green))
                .fillMaxSize()
        ) {
            RegistrationForm(
                modifier = Modifier
                    .padding(32.dp)
                    .clip(shape = RoundedCornerShape(20.dp))
                    .background(color = Color.White)
                    .padding(21.dp)
                    .align(Alignment.Center),
                onEnterClicked = {
                    navigator.push(AuthorizationScreen())
                },
                onRegisterClick = {
                    navigator.push(ProductCategoriesScreen())
                }
            )
        }
    }

    @Composable
    private fun RegistrationForm(
        modifier: Modifier,
        onEnterClicked: () -> Unit,
        onRegisterClick: () -> Unit
    ) {
        Column(
            modifier = modifier
        ) {
            Text(
                text = AnnotatedString(text = stringResource(id = R.string.registration)),
                fontSize = 35.sp,
                fontFamily = FontFamily(
                    Font(R.font.montserrat_bold)
                ),
                color = colorResource(id = R.color.green),
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(modifier = Modifier.size(22.dp))
            Field(
                modifier = Modifier
                    .background(color = Color.White)
                    .border(
                        width = 2.dp,
                        color = colorResource(id = R.color.green),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                hint = "Email",
                icon = R.drawable.profile
            )
            Spacer(modifier = Modifier.size(22.dp))
            Field(
                modifier = Modifier
                    .background(color = Color.White)
                    .border(
                        width = 2.dp,
                        color = colorResource(id = R.color.green),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                hint = "Имя",
                icon = R.drawable.lock
            )
            Spacer(modifier = Modifier.size(22.dp))
            Field(
                modifier = Modifier
                    .background(color = Color.White)
                    .border(
                        width = 2.dp,
                        color = colorResource(id = R.color.green),
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                hint = "Пароль",
                icon = R.drawable.lock
            )
            Spacer(modifier = Modifier.size(22.dp))
            Row(Modifier.fillMaxWidth()) {
                Text(
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            onEnterClicked()
                        },
                    text = stringResource(id = R.string.enter),
                    fontFamily = FontFamily(Font(R.font.montserrat_regular)),
                    fontSize = 13.sp,
                    color = colorResource(id = R.color.green)
                )
                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.5f)
                )
                Text(
                    modifier = Modifier.weight(1f),
                    text = stringResource(id = R.string.forgot_password),
                    fontFamily = FontFamily(Font(R.font.montserrat_regular)),
                    fontSize = 13.sp,
                    color = colorResource(id = R.color.green)
                )
            }
            Spacer(modifier = Modifier.size(24.dp))
            Button(
                modifier = Modifier.align(Alignment.CenterHorizontally),
                colors = ButtonDefaults.buttonColors(containerColor = colorResource(id = R.color.green)),
                onClick = {
                    onRegisterClick()
                }
            ) {
                Text(
                    text = stringResource(id = R.string.registration),
                    fontFamily = FontFamily(Font(R.font.montserrat_semibold)),
                    color = colorResource(id = R.color.white)
                )
            }
        }
    }

}