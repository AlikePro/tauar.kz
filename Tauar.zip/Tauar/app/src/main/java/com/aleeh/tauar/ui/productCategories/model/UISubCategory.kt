package com.aleeh.tauar.ui.productCategories.model

import com.aleeh.tauar.ui.shopsMap.model.UIProduct

data class UISubCategory(
    val id: Int,
    val categoryId: Int,
    val name: String,
    val listOfProducts: List<UIProduct>
)