package com.aleeh.tauar.ui.shopsMap

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import cafe.adriel.voyager.core.screen.Screen
import com.aleeh.tauar.R
import com.aleeh.tauar.ui.components.ComposableLifecycle
import com.aleeh.tauar.ui.components.SearchView
import com.aleeh.tauar.ui.shopsMap.model.UIProduct
import com.aleeh.tauar.ui.shopsMap.model.UIShop
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.logo.Alignment
import com.yandex.mapkit.logo.HorizontalAlignment
import com.yandex.mapkit.logo.VerticalAlignment
import com.yandex.mapkit.map.CameraListener
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.map.MapObjectTapListener
import com.yandex.mapkit.mapview.MapView
import com.yandex.runtime.image.ImageProvider


class ShopsMapScreen : Screen {

    private val viewModel = ShopsMapViewModel()

    private val showSheet =  mutableStateOf(false)

    private val shop: MutableState<UIShop?> = mutableStateOf(null)

    private val markerTapListener = MapObjectTapListener { mapObject, _ ->
        if (mapObject.userData is UIShop) {
            shop.value = mapObject.userData as UIShop
            showSheet.value = true
        }
        true
    }

    @Composable
    override fun Content() {
        ShopsMapContent()
    }

    @Composable
    private fun ShopsMapContent() {
        Box {
            YandexMap(
                onMapClick = {},
                cameraListener = { map, cameraPosition, cameraUpdateReason, b -> })
            if (showSheet.value)
                shop.value?.let {
                    ShopProductsBottomSheet(
                        shop = it,
                        onDismiss = {
                            showSheet.value = false
                        }
                    )
                }
            Spacer(modifier = Modifier.height(16.dp))
            SearchView(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(color = colorResource(id = R.color.grey))
                    .align(androidx.compose.ui.Alignment.TopCenter),
                onSearchClick = {}
            )
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun ShopProductsBottomSheet(shop: UIShop, onDismiss: () -> Unit) {
        val modalBottomSheetState = rememberModalBottomSheetState()

        ModalBottomSheet(
            modifier = Modifier
                .fillMaxWidth(),
            onDismissRequest = { onDismiss() },
            sheetState = modalBottomSheetState,
            dragHandle = { BottomSheetDefaults.DragHandle() },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
            ) {
                Text(
                    modifier = Modifier
                        .align(androidx.compose.ui.Alignment.CenterHorizontally)
                        .padding(vertical = 8.dp),
                    text = shop.name,
                    fontFamily = FontFamily(Font(R.font.montserrat_semibold)),
                    fontSize = 24.sp,
                    color = colorResource(id = R.color.green)
                )
                HorizontalDivider(modifier = Modifier.height(1.dp))
                ProductsList(shop.products)
            }
        }
    }

    @Composable
    private fun ProductsList(productList: List<UIProduct>) {
        LazyVerticalStaggeredGrid(
            modifier = Modifier.padding(top = 8.dp, start = 8.dp, end = 8.dp),
            columns = StaggeredGridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalItemSpacing = 8.dp,
            content = {
                items(productList.size) {
                    ProductItem(productList[it]) {}
                }
            })
    }

    @Composable
    private fun ProductItem(item: UIProduct, onProductItemClick: (UIProduct) -> Unit) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(color = Color.White)
                .fillMaxWidth()
                .clickable {
                    onProductItemClick(item)
                }
        ) {
            Box(
                modifier = Modifier
                    .align(androidx.compose.ui.Alignment.CenterHorizontally)
                    .background(color = colorResource(id = R.color.light_grey))
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
            ) {
                Image(
                    modifier = Modifier
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    painter = painterResource(R.drawable.bread),
                    contentDescription = null,
                    contentScale = ContentScale.Crop
                )
            }
            Text(
                modifier = Modifier.padding(top = 8.dp),
                text = item.name,
                fontFamily = FontFamily(Font(R.font.montserrat_regular)),
                fontSize = 16.sp
            )
            Text(
                text = "${item.price} тг",
                fontFamily = FontFamily(Font(R.font.montserrat_medium)),
                fontSize = 16.sp
            )
        }
    }

    @Composable
    private fun YandexMap(
        cameraListener: CameraListener,
        onMapClick: () -> Unit
    ) {
        val context = LocalContext.current
        val mapView: MapView = remember(context) {
            MapView(context).apply {
                map.addCameraListener(cameraListener)
                map.setMapLoadedListener {
                    onMapClick()
                }
                map.move(CameraPosition(
                    Point(
                        51.169392,
                        71.449074
                    ),
                    10F,
                    0f,
                    0f
                ))
                setupYandexMapView(this)
            }
        }
        viewModel.shops.collectAsState().value.forEach {
            AddPlacemark(shop = it, mapView = mapView)
        }
        ComposableLifecycle(onEvent = { source, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    mapView.onStart()
                }

                Lifecycle.Event.ON_STOP -> {
                    mapView.onStop()
                }

                else -> {
                    Log.d("TAG", "MainScreen: Out of life cycle")
                }
            }
        })
        AndroidView(
            factory = { mapView }
        )
    }

    private fun setupYandexMapView(mapView: MapView) {
        mapView.map.apply {
            set2DMode(true)
            isRotateGesturesEnabled = false
            logo.setAlignment(Alignment(HorizontalAlignment.LEFT, VerticalAlignment.BOTTOM))
        }
    }

    @Composable
    private fun AddPlacemark(
        shop: UIShop,
        mapView: MapView,
    ) {
        val context = LocalContext.current

        LaunchedEffect(key1 = context) {
            val point = Point(
                shop.latitude,
                shop.longitude
            )
            mapView.map?.mapObjects?.let { mapObjects ->
                val placeMark = mapObjects.addPlacemark(
                    point,
                    ImageProvider.fromBitmap(
                        ContextCompat.getDrawable(context, R.drawable.placemark)?.toBitmap()
                    ),
                )
                placeMark.userData = shop
                placeMark.addTapListener(markerTapListener)
            }
        }
    }
}