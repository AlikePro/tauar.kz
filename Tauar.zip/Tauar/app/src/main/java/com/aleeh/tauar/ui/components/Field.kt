package com.aleeh.tauar.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.aleeh.tauar.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Field(modifier: Modifier, hint: String, @DrawableRes icon: Int) {

    val text = remember { mutableStateOf("") }

    Row(
        modifier = modifier, verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            modifier = Modifier.padding(end = 14.dp),
            alignment = Alignment.Center,
            painter = painterResource(id = icon),
            contentDescription = null,
        )
        Spacer(
            modifier = Modifier
                .width(1.dp)
                .height(50.dp)
                .background(color = colorResource(id = R.color.green))
        )
        TextField(
            value = text.value,
            onValueChange = {
                text.value = it
            },
            colors = TextFieldDefaults.textFieldColors(
                cursorColor = Color.White,
                focusedIndicatorColor = colorResource(id = R.color.green),
                unfocusedIndicatorColor = Color.Transparent,
                containerColor = Color.White
            ),
            placeholder = {
                Text(
                    text = hint,
                    fontFamily = FontFamily(
                        Font(R.font.montserrat_bold)
                    ),
                    color = colorResource(id = R.color.green)
                )
            }
        )
    }
}