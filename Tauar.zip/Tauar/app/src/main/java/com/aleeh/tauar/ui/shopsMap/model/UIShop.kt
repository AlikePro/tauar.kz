package com.aleeh.tauar.ui.shopsMap.model

class UIShop (
    val id: Int,
    val name: String,
    val products: List<UIProduct>,
    val latitude: Double,
    val longitude: Double
)