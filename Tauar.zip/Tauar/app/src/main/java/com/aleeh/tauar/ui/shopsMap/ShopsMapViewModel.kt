package com.aleeh.tauar.ui.shopsMap

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aleeh.tauar.ui.shopsMap.model.UIProduct
import com.aleeh.tauar.ui.shopsMap.model.UIShop
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

class ShopsMapViewModel @Inject constructor() : ViewModel() {

    private val _shops = MutableStateFlow<List<UIShop>>(listOf())
    val shops = _shops.asStateFlow()

    private val _onPlacemarkClick = MutableStateFlow(false)
    val onPlacemarkClick = _onPlacemarkClick

    init {
        getShops()
    }

    fun controlSheet(isShow: Boolean) {
        viewModelScope.launch {
            _onPlacemarkClick.emit(isShow)
        }
    }

    private fun getShops() {
        viewModelScope.launch {
            _shops.emit(
                listOf(
                    UIShop(
                        id = 1,
                        name = "Anvar Turan",
                        products = listOf(
                            UIProduct(431, "Cesna", 43, 803),
                            UIProduct(411, "bread", 41, 155),
                            UIProduct(221, "Eggs Ryaba", 22, 1862),
                            UIProduct(311, "potato", 31, 144),
                            UIProduct(312, "Carrot", 31, 174),
                            UIProduct(313, "Cabbage", 31, 156),
                            UIProduct(314, "Onion", 31, 102),
                            UIProduct(212, "chicken", 21, 2286),
                            UIProduct(213, "mince", 21, 3120),
                            UIProduct(421, "Sultan rozhki", 42, 469),
                            UIProduct(611, "sunflower oil", 61, 564),
                            UIProduct(531, "sugar", 53, 362),
                            UIProduct(511, "Lider", 51, 567),
                            UIProduct(521, "buckwheat", 52, 237),
                            UIProduct(541, "salt", 54, 36),
                            UIProduct(121, "President", 12, 450),
                            UIProduct(111, "Zenchenko", 11, 405),
                            UIProduct(131, "FoodMaster", 13, 477)
                        ),
                        51.1225498545862, 71.4011272130271
                    ),
                    UIShop(
                        id = 2,
                        name = "Magnum Sauran",
                        products = listOf(
                            UIProduct(432, "Zhaksy", 43, 535),
                            UIProduct(411, "bread", 41, 210),
                            UIProduct(221, "Eggs Ryaba", 22, 1431),
                            UIProduct(311, "potato", 31, 109),
                            UIProduct(312, "Carrot", 31, 135),
                            UIProduct(313, "Cabbage", 31, 125),
                            UIProduct(314, "Onion", 31, 91),
                            UIProduct(212, "chicken", 21, 2267),
                            UIProduct(211, "beef", 21, 3990),
                            UIProduct(422, "Pietro rozhki", 42, 400),
                            UIProduct(611, "sunflower oil", 61, 685),
                            UIProduct(531, "sugar", 53, 385),
                            UIProduct(511, "Lider", 51, 510),
                            UIProduct(521, "buckwheat", 52, 279),
                            UIProduct(541, "salt", 54, 64),
                            UIProduct(112, "Rodina", 11, 369),
                            UIProduct(111, "Zenchenko", 11, 405)
                        ),
                        51.122010683408845, 71.42074535535514
                    ),
                    UIShop(
                        id = 3,
                        name = "Interfood Highvill",
                        products = listOf(
                            UIProduct(431, "Cesna", 43, 955),
                            UIProduct(411, "bread", 41, 250),
                            UIProduct(221, "Eggs Ryaba", 22, 1710),
                            UIProduct(311, "potato", 31, 150),
                            UIProduct(312, "Carrot", 31, 170),
                            UIProduct(313, "Cabbage", 31, 180),
                            UIProduct(314, "Onion", 31, 148),
                            UIProduct(212, "chicken", 21, 2609),
                            UIProduct(211, "beef", 21, 3290),
                            UIProduct(421, "Sultan rozhki", 42, 439),
                            UIProduct(611, "sunflower oil", 61, 1109),
                            UIProduct(531, "sugar", 53, 620),
                            UIProduct(511, "Lider", 51, 975),
                            UIProduct(521, "buckwheat", 52, 415),
                            UIProduct(541, "salt", 54, 190),
                            UIProduct(111, "Zenchenko", 11, 425),
                            UIProduct(131, "FoodMaster", 13, 445),
                            UIProduct(121, "Emil", 12, 1079),
                            UIProduct(142, "President", 14, 915)
                        ),
                        51.1275632311917, 71.46707289710156
                    )
                )

            )
        }
    }
}