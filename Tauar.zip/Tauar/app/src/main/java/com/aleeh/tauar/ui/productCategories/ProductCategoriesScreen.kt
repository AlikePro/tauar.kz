package com.aleeh.tauar.ui.productCategories

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.navigator.LocalNavigator
import cafe.adriel.voyager.navigator.currentOrThrow
import com.aleeh.tauar.R
import com.aleeh.tauar.ui.components.HeaderView
import com.aleeh.tauar.ui.components.SearchView
import com.aleeh.tauar.ui.productCategories.model.UICategory
import com.aleeh.tauar.ui.productSubCategories.ProductSubCategoriesScreen


class ProductCategoriesScreen : Screen {

    private val viewModel = ProductCategoriesViewModel()

    @Composable
    override fun Content() {
        val navigator = LocalNavigator.currentOrThrow
        ProductCategoriesContent {
            navigator.push(ProductSubCategoriesScreen(it))
        }
    }

    @Composable
    private fun ProductCategoriesContent(onCategoryClick: (UICategory) -> Unit) {

        val categories = viewModel.categories.collectAsState()

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
        ) {
            HeaderView(title = stringResource(id = R.string.categories)) {

            }
            Spacer(modifier = Modifier.height(8.dp))
            SearchView(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(color = colorResource(id = R.color.grey))
                    .padding(horizontal = 16.dp),
                onSearchClick = {
                    viewModel.onSearchClick(it)
                }
            )
            LazyVerticalStaggeredGrid(
                modifier = Modifier.padding(8.dp),
                columns = StaggeredGridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalItemSpacing = 8.dp,
                content = {
                    items(categories.value.size) { i ->
                        ProductCategoryItem(categories.value[i]) {
                            onCategoryClick(it)
                        }
                    }
                })
        }
    }

    @Composable
    private fun ProductCategoryItem(
        item: UICategory,
        onItemClick: (UICategory) -> Unit
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(color = colorResource(id = item.color))
                .fillMaxWidth()
                .clickable {
                    onItemClick(item)
                }
        ) {
            Text(
                modifier = Modifier.padding(16.dp),
                text = item.name,
                fontFamily = FontFamily(Font(R.font.montserrat_semibold)),
                fontSize = 18.sp,
                color = colorResource(id = R.color.white)
            )
            Row {
                Spacer(modifier = Modifier.weight(1f))
                Image(
                    modifier = Modifier
                        .padding(16.dp)
                        .size(70.dp)
                        .clip(CircleShape),
                    painter = painterResource(id = item.icon),
                    contentDescription = null,
                    contentScale = ContentScale.Crop
                )
            }
        }
    }

}