package com.aleeh.tauar.ui.productCategories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aleeh.tauar.R
import com.aleeh.tauar.ui.productCategories.model.UICategory
import com.aleeh.tauar.ui.productCategories.model.UISubCategory
import com.aleeh.tauar.ui.shopsMap.model.UIProduct
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProductCategoriesViewModel @Inject constructor() : ViewModel() {

    private val _categories: MutableStateFlow<List<UICategory>> = MutableStateFlow(listOf())
    val categories = _categories.asStateFlow()

    init {
        getCategories()
    }

    private fun getCategories() = viewModelScope.launch {
        val categories = listOf(
            UICategory(
                id = 1,
                name = "diary products",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 11,
                        categoryId = 1,
                        name = "milk",
                        listOfProducts = listOf(
                            UIProduct(111, "Zenchenko", 11),
                            UIProduct(112, "Rodina", 11)
                        )
                    ),
                    UISubCategory(
                        id = 12,
                        categoryId = 1,
                        name = "curd",
                        listOfProducts = listOf(
                            UIProduct(121, "Emil", 12),
                            UIProduct(122, "President", 12)
                        )
                    ),
                    UISubCategory(
                        id = 13,
                        categoryId = 1,
                        name = "airan",
                        listOfProducts = listOf(
                            UIProduct(131, "FoodMaster", 13)
                        )
                    ),
                    UISubCategory(
                        id = 14,
                        categoryId = 1,
                        name = "butter",
                        listOfProducts = listOf(
                            UIProduct(141, "Maslozavod", 14),
                            UIProduct(142, "President", 14)
                        )
                    )
                ),
                icon = R.drawable.milk,
                color = R.color.green
            ),
            UICategory(
                id = 2,
                name = "meat products",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 21,
                        categoryId = 2,
                        name = "meat",
                        listOfProducts = listOf(
                            UIProduct(211, "beef", 21),
                            UIProduct(212, "chicken", 21),
                            UIProduct(213, "mince", 21)
                        )
                    ),
                    UISubCategory(
                        id = 22,
                        categoryId = 2,
                        name = "eggs",
                        listOfProducts = listOf(
                            UIProduct(221, "Eggs Ryaba", 22)
                        )
                    )
                ),
                icon = R.drawable.meat,
                color = R.color.red
            ),
            UICategory(
                id = 3,
                name = "vegetables",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 31,
                        categoryId = 3,
                        name = "vegetables",
                        listOfProducts = listOf(
                            UIProduct(311, "potato", 31),
                            UIProduct(312, "Carrot", 31),
                            UIProduct(313, "Cabbage", 31),
                            UIProduct(314, "Onion", 31)
                        )
                    )
                ),
                icon = R.drawable.vegetables,
                color = R.color.light_green
            ),
            UICategory(
                id = 4,
                name = "flour products",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 41,
                        categoryId = 4,
                        name = "bread",
                        listOfProducts = listOf(
                            UIProduct(411, "bread", 41)
                        )
                    ),
                    UISubCategory(
                        id = 42,
                        categoryId = 4,
                        name = "pasta",
                        listOfProducts = listOf(
                            UIProduct(421, "Sultan rozhki", 42),
                            UIProduct(422, "Pietro rozhki", 42)
                        )
                    ),
                    UISubCategory(
                        id = 43,
                        categoryId = 4,
                        name = "flour",
                        listOfProducts = listOf(
                            UIProduct(431, "Cesna", 43),
                            UIProduct(432, "Zhaksy", 43)
                        )
                    )
                ),
                icon = R.drawable.bread,
                color = R.color.orange
            ),
            UICategory(
                id = 5,
                name = "goods by weight",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 51,
                        categoryId = 5,
                        name = "rice",
                        listOfProducts = listOf(
                            UIProduct(511, "Lider", 51)
                        )
                    ),
                    UISubCategory(
                        id = 52,
                        categoryId = 5,
                        name = "buckwheat",
                        listOfProducts = listOf(
                            UIProduct(521, "buckwheat", 52)
                        )
                    ),
                    UISubCategory(
                        id = 53,
                        categoryId = 5,
                        name = "sugar",
                        listOfProducts = listOf(
                            UIProduct(531, "sugar", 53)
                        )
                    ),
                    UISubCategory(
                        id = 54,
                        categoryId = 5,
                        name = "salt",
                        listOfProducts = listOf(
                            UIProduct(541, "salt", 54)
                        )
                    )
                ),
                icon = R.drawable.weight_products,
                color = R.color.purple_200
            ),
            UICategory(
                id = 6,
                name = "oil",
                listOfSubcategories = listOf(
                    UISubCategory(
                        id = 61,
                        categoryId = 6,
                        name = "sunflower oil",
                        listOfProducts = listOf(
                            UIProduct(611, "sunflower oil", 61)
                        )
                    )
                ),
                icon = R.drawable.oil,
                color = R.color.yellow
            )
        )
        _categories.emit(categories)
    }

    fun onSearchClick(text: String) = viewModelScope.launch {
        if (text.isNotEmpty()) {
            val searchedList = _categories.value.filter { it.name.startsWith(text) }
            _categories.emit(searchedList)
        } else {
            getCategories()
        }
    }

}