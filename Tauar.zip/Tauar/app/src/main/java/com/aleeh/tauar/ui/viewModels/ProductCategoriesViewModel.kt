package com.aleeh.tauar.ui.viewModels

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class ProductCategoriesViewModel @Inject constructor(): ViewModel() {

    private val _searchName = MutableStateFlow<String>("")
    val searchName: StateFlow<String> = _searchName

}