package com.aleeh.tauar.ui.shopsMap.model

data class UIProduct(
    val id: Int,
    val name: String,
    val subCategoryId: Int,
    val price: Int = 0
)